import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
const Army = Men => {
    class Traning extends Component {
        state = {
            gunshots: 0
        };
        handleGunshots = () => {
            this.setState({ gunshots: this.state.gunshots + 1 });
        };
        render() {
            return (
                <div>
                    <div className="card text-center">
          <div className="card-header">
            HOC Component
          </div></div>
                    <Men
                        hocgunname="AK47"
                        hocgunshots={this.state.gunshots}
                        hochandleGunshots={this.handleGunshots}
                    /></div>
            );
        }
    }
    return Traning;
};

export default Army;