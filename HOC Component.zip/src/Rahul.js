import React, { Component } from 'react'
import Army from './withArm';

class Rahul extends Component {

  render() {
    return (
      <div>
        <div className=" text-center">
          <div className="card-body">
            <h5 className="card-title">Reuses component logic</h5>
            <p className="card-text">write a code in withArm.js file and pass as an Props to chield component</p>
          </div>
          <h3 onMouseOver={this.props.hochandleGunshots}>
            Rahul {this.props.hocgunname} Gunshots :
            {this.props.hocgunshots}
          </h3>
        </div>

      </div>
    );
  }
}
export default Army(Rahul);