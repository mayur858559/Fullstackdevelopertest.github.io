import React, {Component} from 'react';
import Rahul from './Rahul';
import Sonam from './Sonam';
import 'bootstrap/dist/css/bootstrap.min.css';

export default class App extends Component{
  render(){
    return(
      <div>
        <Rahul/>
        <br/>
        <Sonam/>
      </div>
    )
  }
}
