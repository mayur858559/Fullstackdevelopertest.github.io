import React, { Component } from 'react'
import Army from './withArm';
class Sonam extends Component {

    render() {
        return (
            <div>
                <div className=" text-center">
                    <div className="card-body mt-3">
                        <h5 className="card-title">Reuses component logic</h5>
                        <p className="card-text">write a code in withArm.js file and pass as an Props to chield component</p>
                    </div>
                    <h3 className="mb-5" onMouseOver={this.props.hochandleGunshots}>
                        Sonam {this.props.hocgunname} Gunshots :
                        {this.props.hocgunshots}
                    </h3>
                </div>
                <div class="card-footer text-muted" style={{width:'100%', textAlign:'center'}}>
                React Version : "17.0.2", Bootstrap version: "5.0.2"
                </div>
            </div >
        );
    }
}
export default Army(Sonam);