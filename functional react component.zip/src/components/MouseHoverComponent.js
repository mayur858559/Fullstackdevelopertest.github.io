import React from 'react';
import withHoverHOC from './withHoverHOC';

function MouseHoverComponent(props) {
    const { textColor, textHover, ...divProps } = props;
    return (
        <div>
            <h1  className="mt-5" {...divProps} style={{ color: textColor }}>Text {textHover ? 'Changes' : 'Normal'}</h1>
        </div>
    )
}

export default withHoverHOC(MouseHoverComponent);