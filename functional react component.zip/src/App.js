import React from 'react';
import './App.css';
import MouseHoverComponent from './components/MouseHoverComponent';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'

function App() {
  return (
    <div>
<nav className="nav nav-pills flex-column flex-sm-row">
  <a className="flex-sm-fill text-sm-center nav-link active" aria-current="page" href="#">Home</a>
  <a className="flex-sm-fill text-sm-center nav-link" href="#">About Us</a>
  <a className="flex-sm-fill text-sm-center nav-link" href="#">Contact US</a>
</nav>
      <h2 className="mt-5 mx-auto text-center link-success" style={{width:'620px'}}>Click of Mouse Changes Text Color</h2>
    <div className="App mt-5 mx-auto  bg-light border pb-5 mb-5" style={{width:'400px'}}>
     <MouseHoverComponent />
    </div>
    <div class="card-footer text-muted text-center mx-auto" style={{position:'absolute', bottom:'0', width:'100%'}}>
    Created by Mayur Walzade
  </div>
    </div>
  );
}

export default App;
